import UIKit //Libreria que usa Swift

var saludo = "Hola Mundo"

// Ejercicios 1 y 2

// Gabriel
/* Gabriel, Matemáticas Aplicadas y Computación, 20 años */

//Ejercicio 3
let Municipio: String = "Naucalpan de Juarez"
let numBooleano: Bool = true
let entero: Int = 7

//Ejercicio 4
let ejemploUno: String?
let ejemploDos: Double?
let ejemploTres: Bool?
let ejemploCuatro: Int?

//Ejercicio 5
let variable_1: Int = 7
let variable_2: Bool = false
let variable_3: Double = 5.66
let variable_4: String = "El cielo es azul"

/*Declara las variables necesarias para alamcenar tu nombre de pila, tu apellido y tu edad; diferenciando entre var y let. Ejercicio 6*/

let nombre = "Gabriel"
let apellido = "de la Cruz"
var edad = "20"
var mensaje = "Hola, mi nombre es \(nombre), mi apellido es \(apellido) y tengo \(edad) años."
print(mensaje) //Salida: "Hola, mi nombre es Gabriel, mi apellido es de la Cruz y tengo 20 años."
