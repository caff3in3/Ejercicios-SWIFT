import UIKit

/*Ejercicio 1
 Realiza tres operaciones aritméticas y tres operaciones de comparación*/

// Operadores aritméticos

let numero_Uno = 7
let numero_Dos = 11


let multiplicacion = numero_Uno * numero_Dos
print(multiplicacion)

let suma = numero_Uno + numero_Dos
print(suma)

let resta = numero_Uno - numero_Dos
print(resta)

// Operadores de comparación

let igualdad = numero_Uno == numero_Dos

let diferente = numero_Uno != numero_Dos

let esMayor = numero_Uno > numero_Dos

/*Ejercicio 2
 Declara un arreglo de elementos con más de 5 elementos*/

var numeros: [Int] = [3, 1, 5, 2, 4, 6]

/*Ejercicio 3
 Encuentra el número de elementos del arreglo*/

let cantidadNumeros = numeros.count
print(cantidadNumeros)

/* Ejercicio 4
 Imprime el arreglo ordenado usando el método Sorted()*/

let numerosOrdenados = numeros.sorted() //Nuevo arreglo ordenado

/* Ejercicio 5
 Agrega dos elementos al arreglo*/

numeros.append(8)
numeros.append(7)
print(numeros)

/*Ejercicio 6
 Elimina el tercer elemento del arreglo*/

numeros.remove(at: 7)
print(numeros)

/*Ejercicio 7*/

let a = 4
let b = 3

//Si 'a' es más grande que 'b', imprime: "A es más grande que B"
if (a>b)
{
    print("A es más grande que B")
}

/*Ejercicio 8
 En una variable declara tu edad y utilizando el operador ternario, determina ai es mayor de 21 o no. Imprime en pantalla*/

let edad = 20
let resultado = edad > 21 ? "Es mayor de 21" : "No es mayor de 21"
print(resultado)

/*Ejercicio 9
 Haz una estructura if, else if, else para cada variable siguiente donde se determine si un número es positivo, negativo o es cero*/
let num1 = 3
let num2 = -4

// If
if (3 > 0) {
    print("el número es positivo")
}

if (3 < 0) {
    print("el número es negativo")
}

if (3 = 0) {
    print("el número es igual a cero")
}

// Else

if (3 > 0) {
    print("el número es positivo")
} else {
    if (3 < 0 )
        print ("el número es negativo")
} else {
    print ("el número es igual a cero")
        
    }

//Else if

if (3 > 0) {
    print("el número es positivo")
} else if (3 < 0) {
    print ("el número es negativo")
} else {
    print("el número es igual a cero")
}

